import { PageContainer } from '@ant-design/pro-components';

const ControlPannel = function ControlPannel() {
    return <PageContainer>
        我是控制面板中的内容哈
    </PageContainer>;
};
export default ControlPannel;