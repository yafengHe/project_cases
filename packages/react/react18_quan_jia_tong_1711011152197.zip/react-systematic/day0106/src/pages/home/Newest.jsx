import { PageContainer } from '@ant-design/pro-components';

const Newest = function Newest() {
    return <PageContainer>

    </PageContainer>;
};
export default Newest;