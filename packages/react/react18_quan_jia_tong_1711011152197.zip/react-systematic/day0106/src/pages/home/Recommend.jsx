import { PageContainer } from '@ant-design/pro-components';

const Recommend = function Recommend() {
    return <PageContainer>

    </PageContainer>;
};
export default Recommend;