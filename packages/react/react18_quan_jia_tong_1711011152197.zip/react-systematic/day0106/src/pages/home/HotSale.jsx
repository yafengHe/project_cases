import { PageContainer } from '@ant-design/pro-components';

const HotSale = function HotSale() {
    return <PageContainer>

    </PageContainer>;
};
export default HotSale;