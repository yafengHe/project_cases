import { PageContainer } from '@ant-design/pro-components';

const Classify = function Classify() {
    return <PageContainer>

    </PageContainer>;
};
export default Classify;