import { PageContainer } from '@ant-design/pro-components';

const Member = function Member() {
    return <PageContainer>

    </PageContainer>;
};
export default Member;