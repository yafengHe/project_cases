import { PageContainer } from '@ant-design/pro-components';

const System = function System() {
    return <PageContainer>

    </PageContainer>;
};
export default System;