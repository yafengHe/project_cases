import { PageContainer } from '@ant-design/pro-components';

const Order = function Order() {
    return <PageContainer>

    </PageContainer>;
};
export default Order;