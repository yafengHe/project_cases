import { PageContainer } from '@ant-design/pro-components';

const Goods = function Goods() {
    return <PageContainer>

    </PageContainer>;
};
export default Goods;